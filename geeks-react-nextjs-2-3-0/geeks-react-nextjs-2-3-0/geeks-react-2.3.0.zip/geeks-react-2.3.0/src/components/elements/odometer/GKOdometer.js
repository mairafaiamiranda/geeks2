// import node module libraries
import React from 'react';
import Odometer from 'react-odometerjs';

const GKOdometer = ({ value }) => {
	return <Odometer value={value} />;
};

export default GKOdometer;
