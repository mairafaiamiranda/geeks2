// import node module libraries
import { Fragment } from 'react';

const BlankLayout = (props) => {
	return <Fragment>{props.children}</Fragment>;
};

export default BlankLayout;
