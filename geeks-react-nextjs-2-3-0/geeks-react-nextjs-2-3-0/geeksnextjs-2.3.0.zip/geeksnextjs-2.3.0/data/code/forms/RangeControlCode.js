export const BasicRangeCode = `
<Form>
    <Form.Label>Range</Form.Label>
    <Form.Range />
</Form>
`.trim();

export const RangeControlCode = [BasicRangeCode];

export default RangeControlCode;
