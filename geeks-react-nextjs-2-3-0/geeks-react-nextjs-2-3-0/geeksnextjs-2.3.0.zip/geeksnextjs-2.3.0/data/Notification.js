const Notification = [
	{
		id: 1,
		read: false,
		image: '/images/avatar/avatar-1.jpg',
		sender: 'Kristin Watson',
		date: '2 hours ago',
		time: '2:19 PM',
		message: `Krisitn Watsan like your comment on course Javascript Introduction!`
	},
	{
		id: 2,
		read: true,
		image: '/images/avatar/avatar-2.jpg',
		sender: 'Brooklyn Simmons',
		date: 'Oct 9,',
		time: '1:20 PM',
		message: `Just launched a new Courses React for Beginner.`
	},
	{
		id: 3,
		read: true,
		image: '/images/avatar/avatar-3.jpg',
		sender: 'Jenny Wilson',
		date: 'Oct 9,',
		time: '1:56 PM',
		message: `Krisitn Watsan like your comment on course Javascript Introduction!`
	},
	{
		id: 4,
		read: true,
		image: '/images/avatar/avatar-4.jpg',
		sender: 'Sina Ray',
		date: 'Oct 9,',
		time: '1:56 PM',
		message: `You earn new certificate for complete the Javascript Beginner course.`
	}
];

export default Notification;
