const InvoiceData = [
	{
		id: 1008,
		invoicedate: '17 April 2020, 10:45pm',
		amount: 39,
		status: 'Due',
		pdf: '/images/pdf/invoiceFile.pdf'
	},
	{
		id: 1007,
		invoicedate: '17 April 2020, 10:45pm',
		amount: 39,
		status: 'Complete',
		pdf: '/images/pdf/invoiceFile.pdf'
	},
	{
		id: 1006,
		invoicedate: '17 Feb 2020, 10:45pm',
		amount: 39,
		status: 'Complete',
		pdf: '/images/pdf/invoiceFile.pdf'
	},
	{
		id: 1005,
		invoicedate: '17 Jan 2020, 10:45pm',
		amount: 39,
		status: 'Complete',
		pdf: '/images/pdf/invoiceFile.pdf'
	},
	{
		id: 1004,
		invoicedate: '17 Dec 2019, 10:45pm',
		amount: 39,
		status: 'Complete',
		pdf: '/images/pdf/invoiceFile.pdf'
	},
	{
		id: 1003,
		invoicedate: '17 Nov 2019, 10:45pm',
		amount: 39,
		status: 'Complete',
		pdf: '/images/pdf/invoiceFile.pdf'
	},
	{
		id: 1002,
		invoicedate: '17 Oct 2019, 10:45pm',
		amount: 39,
		status: 'Complete',
		pdf: '/images/pdf/invoiceFile.pdf'
	},
	{
		id: 1001,
		invoicedate: '17 Sept 2019, 10:45pm',
		amount: 39,
		status: 'Complete',
		pdf: '/images/pdf/invoiceFile.pdf'
	}
];

export default InvoiceData;
