export const ActivityData = [
	{
		id: 1,
		name: 'Jenny Wilson',
		image: '/images/avatar/avatar-1.jpg',
		topic: 'Just buy the courses”Build React Application Tutorial”',
		courses: 6,
		postedon: '2m ago',
		students: 50274,
		rating: 4.6,
		reviews: 12230,
		status: 'offline'
	},
	{
		id: 2,
		name: 'Dianna Smiley',
		image: '/images/avatar/avatar-2.jpg',
		topic: 'Comment on “Bootstrap Tutorial” Says “Hi,I m irene...',
		courses: 3,
		postedon: '1 hour ago',
		students: 26060,
		rating: 4.4,
		reviews: 11230,
		status: 'online'
	},
	{
		id: 3,
		name: 'Nia Sikhone',
		image: '/images/avatar/avatar-3.jpg',
		topic: 'Just share your article on Social Media..',
		courses: 12,
		postedon: '2 month ago',
		students: 26060,
		rating: 4.4,
		reviews: 11230,
		status: 'away'
	},
	{
		id: 4,
		name: 'Irene Hargrove',
		image: '/images/avatar/avatar-7.jpg',
		topic: 'Comment on “Bootstrap Tutorial” Says “Hi,I m irene...',
		courses: 3,
		postedon: '1 hour ago',
		students: 26060,
		rating: 4.4,
		reviews: 11230,
		status: 'offline'
	}
];

export default ActivityData;
