const OurTeamData = [
	{
		id: 1,
		name: 'Paul Haney',
		designation: 'CEO',
		image: '/images/avatar/avatar-1.jpg'
	},
	{
		id: 2,
		name: 'Gail Lanier',
		designation: 'Engineering',
		image: '/images/avatar/avatar-2.jpg'
	},
	{
		id: 3,
		name: 'Gail Lanier',
		designation: 'Manager',
		image: '/images/avatar/avatar-3.jpg'
	},
	{
		id: 4,
		name: 'Mary Holler',
		designation: 'Sales',
		image: '/images/avatar/avatar-4.jpg'
	},
	{
		id: 5,
		name: 'Gilbert Farr',
		designation: 'Oprator',
		image: '/images/avatar/avatar-5.jpg'
	},
	{
		id: 6,
		name: 'Charlie Holland',
		designation: 'Designer',
		image: '/images/avatar/avatar-6.jpg'
	},
	{
		id: 7,
		name: 'James Butler',
		designation: 'Developer',
		image: '/images/avatar/avatar-7.jpg'
	},
	{
		id: 8,
		name: 'Richard Lane',
		designation: 'Insight',
		image: '/images/avatar/avatar-8.jpg'
	},
	{
		id: 9,
		name: 'Gail Lanier',
		designation: 'Seo',
		image: '/images/avatar/avatar-9.jpg'
	},
	{
		id: 10,
		name: 'Mary Holler',
		designation: 'Content',
		image: '/images/avatar/avatar-10.jpg'
	},
	{
		id: 11,
		name: 'Gilbert Farr',
		designation: 'Designer',
		image: '/images/avatar/avatar-11.jpg'
	},
	{
		id: 12,
		name: 'James Butler',
		designation: 'Developer',
		image: '/images/avatar/avatar-12.jpg'
	}
];

export default OurTeamData;
