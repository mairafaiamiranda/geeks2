export const settings = {
    app: {
        name: "Geeks NextJs",
        version: "2.3.0"
    },
    theme: {
        skin: "light" // possible values are light, dark
    }
};
export default { settings };
